export default function App() {
  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>Bienvenido a la app de calorías con maní 🥜</h1>
      <p>Pronto más funciones aquí...</p>
    </div>
  );
}